RENZ BOT v64 APK BUILD FROM PHONE

1. Create a NEW GitHub repository:
   renz-bot-v64-apk-final

2. Upload ONLY this file to the repo root:
   renz_bot_v64_project_payload.zip

3. Create a new file with exact path:
   .github/workflows/build-apk.yml

4. Copy all content from:
   BUILD_APK_WORKFLOW.yml
   and paste it into build-apk.yml.

5. Commit changes.

6. Go to Actions > Build RENZ Bot v64 APK > Run workflow.

7. When green/success, download artifact:
   RENZ-Bot-v64-APK

8. Extract and install the APK.
